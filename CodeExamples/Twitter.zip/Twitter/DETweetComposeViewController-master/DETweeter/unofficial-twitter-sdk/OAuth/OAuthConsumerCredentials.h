//#error Use your Twitter keys from developer.twitter.com

#define kDEConsumerKey @"HOrf17Okx8vB1bTWonJmA"
#define kDEConsumerSecret @"OXOynr565F6PtFnMYubNRGC4fFUSTYpRpmwoXDUSUpQ"
