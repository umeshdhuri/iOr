#!/bin/sh

git submodule update --recursive