//
//  TwitterExampleTests.h
//  TwitterExampleTests
//
//  Created by Umesh Dhuri on 02/01/13.
//  Copyright (c) 2013 Umesh.Dhuri@synechron.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TwitterExampleTests : SenTestCase

@end
