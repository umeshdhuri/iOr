//
//  TMViewController.h
//  iOSReachabilityTestARC
//
//  Created by Tony Million on 21/11/2011.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMViewController : UIViewController

@property (assign, nonatomic) IBOutlet UILabel * blockLabel;
@property (assign, nonatomic) IBOutlet UILabel * notificationLabel;

@end
