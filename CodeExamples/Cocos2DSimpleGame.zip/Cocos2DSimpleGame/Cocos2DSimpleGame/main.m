//
//  main.m
//  Cocos2DSimpleGame
//
//  Created by Umesh Dhuri on 22/01/13.
//  Copyright Umesh.Dhuri@synechron.com 2013. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
