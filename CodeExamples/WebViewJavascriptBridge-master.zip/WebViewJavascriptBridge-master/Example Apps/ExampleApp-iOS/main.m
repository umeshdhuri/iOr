#import <UIKit/UIKit.h>

#import "ExampleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ExampleAppDelegate class]));
    }
}
